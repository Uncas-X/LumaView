.. Copyright (C) 2001-2023 Artifex Software, Inc.
.. All Rights Reserved.

.. raw:: html

   <hr>

   This software is provided AS-IS with no warranty, either express or implied. This software is distributed under license and may not be copied, modified or distributed except as expressly authorized under the terms of that license. Refer to licensing information at <a href="https://www.artifex.com/?utm_source=rtd-ghostscript&utm_medium=rtd&utm_content=footer-link">artifex.com</a> or contact Artifex Software, Inc., 39 Mesa Street, Suite 108A, San Francisco, CA 94129, USA, for further information.

.. note - this ensures that the Sphinx build system will pull in the image (as it is referenced in an RST file) to _images,
   we don't want to display it via rst markup due to limitations (hence width:0), however we do want it available for our raw HTML
   which we use in header.rst.

.. image:: images/discord-mark-blue.svg
          :alt: Discord logo
          :width: 0
          :height: 0
          :target: https://discord.gg/TSpYGBW4eq

.. image:: images/icon-docx.svg
          :alt: MS Word logo
          :width: 0
          :height: 0

.. image:: images/icon-odt.svg
          :alt: MS Word logo
          :width: 0
          :height: 0

.. image:: images/icon-xlsx.svg
          :alt: MS Word logo
          :width: 0
          :height: 0

.. image:: images/icon-pptx.svg
          :alt: MS Word logo
          :width: 0
          :height: 0

.. image:: images/icon-txt.svg
          :alt: MS Word logo
          :width: 0
          :height: 0

.. image:: images/icon-hangul.svg
          :alt: Hangul logo
          :width: 0
          :height: 0

